# Ingeniería de Features con SQL Analítico Avanzado: Churn en E-commerce

Este proyecto transforma datos crudos de pedidos de un e-commerce en un **dataset de entrenamiento con una fila por usuario**, listo para un modelo de predicción de abandono (*churn*). Todo el trabajo se hace en SQL (PostgreSQL), con funciones de ventana, agregaciones y un manejo explícito de nulos.

## Estructura del repositorio

```
.
├── README.md
└── sql/
    ├── 00_esquema_y_datos.sql   # Tablas users, orders, order_items + datos de ejemplo
    └── 01_features_churn.sql    # Consulta principal: genera las features por usuario
```

## Cómo ejecutarlo

Requiere PostgreSQL 13 o superior.

```bash
createdb ecommerce
psql -d ecommerce -f sql/00_esquema_y_datos.sql
psql -d ecommerce -f sql/01_features_churn.sql
```

Para generar el dataset con otra fecha, cambiá los valores del CTE `parametros` al inicio de `01_features_churn.sql`:

| Parámetro | Valor por defecto | Significado |
|---|---|---|
| `fecha_corte` | `2026-11-01` | Fecha del *snapshot*. Solo se usan pedidos **anteriores** a esta fecha. |
| `meses_historia` | `12` | Cantidad de meses previos que se usan para el promedio histórico de la tendencia. |
| `ultimo_mes_cerrado` | `2026-10-01` | Se calcula a partir de la fecha de corte: es el último mes completo. |

## Modelo de datos

| Tabla | Columnas principales | Descripción |
|---|---|---|
| `users` | `user_id`, `signup_date`, `pais` | Usuarios registrados |
| `orders` | `order_id`, `user_id`, `order_date`, `status` | Encabezado del pedido (`completed`, `cancelled`, `returned`) |
| `order_items` | `order_id`, `product_id`, `quantity`, `unit_price` | Líneas de cada pedido |

Los datos de ejemplo incluyen a propósito casos borde: un usuario que nunca compró, uno con pedidos cancelados, otro con una compra posterior a la fecha de corte, una clienta nueva y un cliente que dejó de comprar.

## Lógica de la consulta (paso a paso)

La consulta está organizada en CTEs, de modo que cada paso se puede leer y probar por separado:

1. **`parametros`**: define la fecha de corte y la ventana de historia en un solo lugar.
2. **`pedidos_validos`**: suma `quantity * unit_price` por pedido. Solo deja los pedidos con `status = 'completed'` y fecha anterior al corte. El `GROUP BY` incluye todas las columnas que no son agregadas.
3. **`pedidos_con_ventanas`**: aplica funciones de ventana a nivel pedido:
   - `ROW_NUMBER() OVER (PARTITION BY user_id ORDER BY order_date DESC)` marca el pedido más reciente.
   - `LAG(order_date) OVER (PARTITION BY user_id ORDER BY order_date)` calcula los días desde el pedido anterior.
4. **`metricas_usuario`**: agrega a nivel usuario (R, F, M y métricas complementarias).
5. **`calendario_usuario`**: con `GENERATE_SERIES` arma una fila por usuario y mes, **incluidos los meses sin compras**. Sin esto, el promedio mensual se calcularía solo sobre los meses con compras y quedaría inflado.
6. **`gasto_mensual`**: hace un `LEFT JOIN` del calendario con los pedidos. Los meses sin compras quedan en `0`.
7. **`gasto_con_promedio` / `tendencia_usuario`**: `AVG(gasto_mes) OVER (PARTITION BY user_id ORDER BY mes ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING)` calcula, para cada mes, el promedio de los meses **anteriores** del mismo usuario. Después se toma solo el último mes cerrado.
8. **`dataset_base`**: parte de **todos** los usuarios (`LEFT JOIN`) y reemplaza los nulos con valores coherentes.
9. **Resultado final**: agrega scores RFM de 1 a 5 con `NTILE(5) OVER (...)` y un ranking de gasto con `RANK() OVER (...)`.

**Funciones de ventana usadas:** `ROW_NUMBER`, `LAG`, `AVG OVER`, `COUNT OVER`, `NTILE` y `RANK`.

## Diccionario de features

### Features principales (RFM + Tendencia)

| Feature | Cálculo | Objetivo y utilidad para predecir churn |
|---|---|---|
| **`recency_dias`** | `fecha_corte - fecha de la última compra` | Mide cuánto hace que el cliente no compra. Suele ser **el predictor más fuerte de churn**: a más días sin comprar, mayor la probabilidad de que el cliente ya se haya ido. |
| **`frequency_pedidos`** | `COUNT(DISTINCT order_id)` de pedidos completados | Mide el hábito de compra. Los clientes que compran seguido tienen un vínculo más fuerte con la tienda y abandonan menos. Con `DISTINCT` se evita contar dos veces un pedido que tiene varias líneas. |
| **`monetary_total`** | `SUM(quantity * unit_price)` | Mide el valor del cliente. No siempre predice churn por sí sola, pero sirve para **priorizar** las acciones de retención: perder a un cliente de alto valor cuesta más. |
| **`trend_gasto`** | `gasto del último mes - promedio mensual de los 12 meses previos` | Mide la **dirección** del comportamiento. Una tendencia negativa (el cliente gasta menos que su promedio) es una señal temprana de abandono, incluso cuando la recency todavía es baja. |

### Features complementarias

| Feature | Cálculo | Utilidad |
|---|---|---|
| `antiguedad_dias` | `fecha_corte - signup_date` | Da contexto a las demás features: 2 pedidos no significan lo mismo para un cliente de 1 mes que para uno de 2 años. |
| `tiene_compras` | `1` si tiene al menos un pedido válido, si no `0` | Permite al modelo separar a los usuarios que nunca compraron (un problema de activación) de los que dejaron de comprar (churn real). |
| `gasto_ultimo_mes` | Gasto en el último mes cerrado | Es un componente de la tendencia y una señal de actividad reciente. |
| `promedio_mensual_historico` | Promedio mensual de los meses anteriores (incluye los meses en 0) | Es la línea base del cliente; el otro componente de la tendencia. |
| `ticket_promedio` | `AVG(importe del pedido)` | Distingue a quienes compran poco y caro de quienes compran mucho y barato. |
| `importe_ultimo_pedido` | Importe del pedido con `ROW_NUMBER = 1` | Si el último pedido es mucho menor que el ticket promedio, puede indicar desinterés. |
| `gasto_ultimos_90d` | Gasto en los 90 días previos al corte | Es una versión monetaria y de corto plazo de la recency. |
| `dias_promedio_entre_pedidos` | `AVG(order_date - LAG(order_date))` | Representa el ciclo de compra propio de cada cliente. Si `recency_dias` es mucho mayor que este valor, el cliente está "atrasado" respecto de su propio hábito. |
| `score_recency`, `score_frequency`, `score_monetary` | `NTILE(5)` sobre cada métrica (5 = mejor) | Son versiones discretas y robustas a valores extremos. Sirven para segmentar (por ejemplo, "Campeones" o "En riesgo") y para modelos simples. |
| `ranking_gasto` | `RANK() OVER (ORDER BY monetary_total DESC)` | Es la posición del cliente según su valor dentro de la base. |

## Manejo de nulos

Un `LEFT JOIN` desde `users` garantiza que **todos** los usuarios aparezcan en el dataset, incluso los que no tienen pedidos. Los nulos se reemplazan así:

| Caso | Valor asignado | Motivo |
|---|---|---|
| Frequency, Monetary, gastos y tendencia sin compras | `0` | No compró nada, así que el valor real es cero, no "desconocido". |
| Recency sin compras | Días desde el alta | Es el tiempo máximo que lleva sin comprar. Usar `0` le diría al modelo que compró hoy, lo contrario de la realidad. |
| Días entre pedidos con 0 o 1 pedido | Antigüedad en días | No hay intervalo observable; se usa un valor alto y coherente en lugar de `NULL`. |
| Promedio histórico sin meses previos | `0` | La columna `meses_en_historico` (en el CTE) indica cuándo pasa esto. |

## Cuidados para no sesgar las métricas

- **Sin data leakage:** todo se calcula con `order_date < fecha_corte`. En los datos de ejemplo, Gabriela tiene una compra el 2026-11-10 que queda excluida a propósito. Si se colara, el modelo "vería el futuro".
- **Solo meses cerrados:** la tendencia compara el **último mes completo** (octubre) y no el mes en curso, que estaría incompleto y daría una tendencia artificialmente negativa.
- **Ventana de historia acotada:** el promedio usa como máximo 12 meses previos y nunca empieza antes del mes de alta. Así no se mezclan comportamientos muy antiguos ni se penaliza a los clientes nuevos con meses en los que todavía no existían.
- **Meses en cero incluidos:** el calendario mensual evita que el promedio se calcule solo con los meses en que hubo compras.
- **Solo pedidos válidos:** los pedidos cancelados o devueltos no cuentan como actividad.

## Resultado con los datos de ejemplo

| user_id | recency_dias | frequency_pedidos | monetary_total | gasto_ultimo_mes | promedio_mensual_historico | trend_gasto | Interpretación |
|---|---|---|---|---|---|---|---|
| 1 Ana | 4 | 7 | 510.00 | 220.00 | 24.17 | **+195.83** | Activa y en crecimiento |
| 2 Bruno | 71 | 5 | 1380.00 | 0.00 | 115.00 | **-115.00** | Cliente valioso en riesgo de churn |
| 3 Carla | 14 | 2 | 115.00 | 75.00 | 40.00 | +35.00 | Nueva y activa |
| 4 Diego | 245 | 0 | 0.00 | 0.00 | 0.00 | 0.00 | Nunca compró (sin nulos) |
| 5 Elena | 367 | 3 | 330.00 | 0.00 | 15.00 | -15.00 | Ya abandonó |
| 6 Facundo | 160 | 1 | 75.00 | 0.00 | 9.38 | -9.38 | Los cancelados no cuentan |
| 7 Gabriela | 23 | 2 | 150.00 | 90.00 | 10.00 | +80.00 | La compra posterior al corte quedó excluida |

## Próximo paso: la etiqueta de churn

Para entrenar un modelo supervisado, a este dataset se le agrega una etiqueta calculada **después** de la fecha de corte. Por ejemplo: `churn = 1` si el usuario no realiza ningún pedido completado en los 60 días siguientes a `fecha_corte`. Si se generan varios *snapshots* (una fecha de corte por mes), se obtiene más historia para entrenar sin mezclar pasado y futuro.
